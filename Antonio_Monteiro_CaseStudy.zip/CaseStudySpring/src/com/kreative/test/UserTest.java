package com.kreative.test;
/*
 * CRUD Operation test cases for User Entity
 */
import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.junit.runners.Parameterized;

import com.kreative.entities.User;
import com.kreative.services.UserServices;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(Parameterized.class)
public class UserTest {
	UserServices us = new UserServices();
	User expected;
	
	public UserTest(User expected) {
		super();
		this.expected = expected;
	}
	
	@SuppressWarnings("rawtypes")
	@Parameterized.Parameters
	public static Collection params() {
		return Arrays.asList(new Object[][] {
			{new User("monant95@live.com", "123123", "Antonio", "Monteiro", "Lynn", "Massachusetts",
			"617-123-8888", "Photographer")}
		});
	}
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void AtestCreateUser() {
		boolean result;
		System.out.print("Create User Test: ");
		User newUser = new User("testuser8@test.com", "123123", "Antonio", "Monteiro", "Lynn", "Massachusetts",
				"617-123-8998", "Photographer");
		result = us.createUser(newUser);
		System.out.println(result);
		assertTrue(result);
	}
	
	@Test
	public final void BtestValidateUser() {
		String email = "testuser8@test.com";
		String password = "123123";
		boolean result = us.validateUser(email, password);
		assertTrue(result);
	}
	
	@Test
	public final void CtestGetUserById() {
		User newUser = us.getUserById(1);
		boolean actual = newUser.getEmail().equals(expected.getEmail());
		assertTrue(actual);
	}
	
	@Test
	public final void DtestGetUserByEmail() {
		User newUser = us.getUserByEmail("monant95@live.com");
		boolean actual = newUser.getEmail().equals(expected.getEmail());
		assertTrue(actual);
	}
	
	@Test
	public final void EtestGetAllUsers() {
		List<User> userList = us.getAllUsers();
		boolean actual = userList.contains(expected);
		assertTrue(actual);
	}
	
	@Test
	public final void FtestGetUsersByState() {
		List<User> userList = us.getUsersByState("Massachusetts");
		boolean actual = userList.contains(expected);
		assertTrue(actual);
	}
	
	@Test
	public final void GtestGetUsersByJob() {
		List<User> userList = us.getUsersByJob("Photographer");
		boolean actual = userList.contains(expected);
		assertTrue(actual);
	}
	
	@Test
	public final void HtestUpdateUserPhone() {
		User newuser = us.getUserByEmail("testuser8@test.com");
		boolean result = us.updateUserPhone(newuser, "617-987-0101");
		assertTrue(result);
	}
	
	@Test
	public final void ItestCreateUserDirectory() {
		User newUser = us.getUserByEmail("testuser8@test.com");
		boolean result = us.createUserDirectory(newUser);
		assertTrue(result);
	}
	
	@Test
	public final void JtestUpdateUserEmail() {
		User newUser = us.getUserByEmail("testuser8@test.com");
		boolean result = us.updateUserEmail(newUser, "testuser88@test.com");
		assertTrue(result);
	}
	
}
