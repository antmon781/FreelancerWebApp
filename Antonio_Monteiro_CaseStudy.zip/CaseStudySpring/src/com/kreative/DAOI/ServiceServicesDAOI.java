package com.kreative.DAOI;

import java.util.List;

import com.kreative.entities.Service;
import com.kreative.entities.User;

public interface ServiceServicesDAOI {

	boolean addService(Service service);

	Service getServiceById(int id);

	boolean deleteService(Service service);

	List<Service> getServicesByUser(User user);

	boolean deleteServiceById(int serviceId);

}
