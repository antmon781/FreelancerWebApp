package com.kreative.DAOI;

import com.kreative.entities.Photograph;

public interface PhotographServicesDAOI {

	boolean deletePhoto(Photograph photograph);

	boolean addPhoto(Photograph photograph);

	Photograph getPhotoById(int photoId);

}
