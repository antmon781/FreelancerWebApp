package com.kreative.DAOI;

import java.util.List;

import com.kreative.entities.User;

public interface UserServicesDAOI {

	boolean createUser(User user);

	boolean validateUser(String email, String password);

	User getUserByEmail(String email);

	List<User> getAllUsers();

	User getUserById(int id);

	boolean updateUserPhone(User user, String phone);

	boolean updateUserEmail(User user, String email);

	boolean updateUserPassword(User user, String password);

	List<User> getUsersByJob(String job);

	List<User> getUsersByState(String state);

	boolean createUserDirectory(User user);
	
}
