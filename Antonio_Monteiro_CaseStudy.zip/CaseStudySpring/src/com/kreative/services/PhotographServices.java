package com.kreative.services;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import com.kreative.DAOI.PhotographServicesDAOI;
import com.kreative.entities.Photograph;
import com.kreative.entities.User;

public class PhotographServices implements PhotographServicesDAOI{
	
	@Override
	//creates record in photograph entity
	public boolean addPhoto(Photograph photograph) {
		
		boolean result = true;
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("KreativeVer2");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(photograph);
			entityManager.getTransaction().commit();
		}
		
		catch(PersistenceException e) {
			e.getMessage();
			System.out.println(e);
			result = false;
		}
		
		finally {
			entityManager.close();
			entityManagerFactory.close();
		}
		return result;
	}
	
	@Override
	// returns record from photograph entity where primary key matches int parameter
	public Photograph getPhotoById(int photoId) {
		
		Photograph photo = new Photograph();
		photo.setPhotoId(photoId);
		Photograph foundPhoto ;
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("KreativeVer2");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		try {
			foundPhoto = entityManager.find(Photograph.class, photo.getPhotoId());
			if (foundPhoto!=null)
				return foundPhoto;
		} 
		catch(PersistenceException e) {
			e.getMessage();
			return null;
		}
		finally {
			entityManager.close();
			entityManagerFactory.close();
		}
		return foundPhoto;
		
	}
	
	@Override
	//deletes record from photograph table
	public boolean deletePhoto(Photograph photograph) {
		boolean result = true;
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("KreativeVer2");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		try {
		entityManager.getTransaction().begin();
		entityManager.remove(photograph);
		entityManager.getTransaction().commit();
		}
		
		catch(PersistenceException e) {
			e.getMessage();
			result = false;
		}
		
		finally {
			entityManager.close();
			entityManagerFactory.close();
		}
		return result;
	}
	
	//returns list of photograph records where foreign key user matches field user 
	public List<Photograph> getPhotographsByUser(User user) {
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("KreativeVer2");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Query query = entityManager.createNamedQuery("queryPhotographsByUser");
		query.setParameter("user", user);
		@SuppressWarnings("unchecked")
		List<Photograph> userPhotographs = query.getResultList();
		entityManager.close();
		entityManagerFactory.close();
		return userPhotographs;
	}
	
	//deletes photograph record from photograph entity where int matches field 'photoId'
	public boolean deletePhotographById(int photoId) {
		
		boolean result = true;
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("KreativeVer2");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		try {
			Photograph photograph = entityManager.find(Photograph.class, photoId);
			entityManager.getTransaction().begin();
			entityManager.remove(photograph);
			entityManager.getTransaction().commit();
		}
		catch(PersistenceException e) {
			e.getMessage();
		}
		finally {
			entityManager.close();
			entityManagerFactory.close();
		}
		
		return result;
	}

}
