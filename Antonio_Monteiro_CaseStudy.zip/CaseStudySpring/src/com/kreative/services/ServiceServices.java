package com.kreative.services;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import com.kreative.DAOI.ServiceServicesDAOI;
import com.kreative.entities.Service;
import com.kreative.entities.User;

public class ServiceServices implements ServiceServicesDAOI {
	
	@Override
	//inserts service record into service entity
	public boolean addService(Service service) {
		boolean result = true;
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("KreativeVer2");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		try {
		entityManager.getTransaction().begin();
		entityManager.persist(service);
		entityManager.getTransaction().commit();
		}
		
		catch(PersistenceException e) {
			e.getMessage();
			result = false;
		}
		
		finally {
			entityManager.close();
			entityManagerFactory.close();
		}
		return result;
	}
	
	@Override
	//returns service record by primary key id
	public Service getServiceById(int id) {
		Service service = new Service();
		service.setServiceId(id);
		Service foundService;
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("KreativeVer2");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		try {
			foundService = entityManager.find(Service.class, service.getServiceId());
			if (foundService!=null)
				return foundService;
		} 
		catch(PersistenceException e) {
			e.getMessage();
			return null;
		}
		finally {
			entityManager.close();
			entityManagerFactory.close();
		}
		return foundService;
		
	}
	
	@Override
	//deletes service record from service entity
	public boolean deleteService(Service service) {
		boolean result = true;
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("KreativeVer2");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		try {
		entityManager.getTransaction().begin();
		entityManager.remove(service);
		entityManager.getTransaction().commit();
		}
		
		catch(PersistenceException e) {
			e.getMessage();
			result = false;
		}
		
		finally {
			entityManager.close();
			entityManagerFactory.close();
		}
		return result;
	}
	
	@Override
	//returns list of service records by foreign key 'user'
	public List<Service> getServicesByUser(User user) {
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("KreativeVer2");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Query query = entityManager.createNamedQuery("queryServicesByUser");
		query.setParameter("user", user);
		@SuppressWarnings("unchecked")
		List<Service> userServicesList= query.getResultList();
		entityManager.close();
		entityManagerFactory.close();
		return userServicesList;
	}
	
	@Override
	//deletes service record by primary key 'serviceId'
	public boolean deleteServiceById(int serviceId) {
		
		boolean result = true;
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("KreativeVer2");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		try {
			Service service = entityManager.find(Service.class, serviceId);
			entityManager.getTransaction().begin();
			entityManager.remove(service);
			entityManager.getTransaction().commit();
		}
		catch(PersistenceException e) {
			e.getMessage();
			System.out.println(e);
		}
		finally {
			entityManager.close();
			entityManagerFactory.close();
		}
		
		return result;
	}
}
