package com.kreative.services;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import com.kreative.DAOI.UserServicesDAOI;
import com.kreative.entities.User;

public class UserServices implements UserServicesDAOI{
	
	@Override
	//adds a new user to the database
	public boolean createUser(User user) {
		boolean result = true;
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("KreativeVer2");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		try {
		entityManager.getTransaction().begin();
		entityManager.persist(user);
		entityManager.getTransaction().commit();
		}
		
		catch(PersistenceException e) {
			e.getMessage();
			result = false;
		}
		
		finally {
			entityManager.close();
			entityManagerFactory.close();
		}
		return result;
	}
	
	@Override
	//validates strings match values in row of user table
	public boolean validateUser(String email, String password) {
		boolean result = true;
		User user = new User();
		user.setEmail(email);
		user.setPassword(password);
		
		User foundUser;
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("KreativeVer2");
		EntityManager entityManager = entityManagerFactory.createEntityManager();

		try {
			Query query = entityManager.createNamedQuery("getUserByEmail");
			query.setParameter("email", user.getEmail());
			foundUser = (User) query.getSingleResult();
			if (!foundUser.getPassword().equals(user.getPassword()))
				result = false;
		}

		catch(PersistenceException e) {
			e.getMessage();
			result = false;

		}

		finally {
			entityManager.close();
			entityManagerFactory.close();
		}
		return result;
	}
	
	@Override
	//returns user entity by searching user table by primary key
	public User getUserById(int id) {
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("KreativeVer2");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		User foundUser = null;
		
		try {
			foundUser = entityManager.find(User.class, id);
		}

		catch(PersistenceException e) {
			e.getMessage();

		}

		finally {
			entityManager.close();
			entityManagerFactory.close();
		}
		return foundUser;
	}
	
	@Override
	//returns user entity by searching user table by unique column 'email'
	public User getUserByEmail(String email) {
		User user = new User();
		user.setEmail(email);
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("KreativeVer2");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		User foundUser = null;
		try {
			Query query = entityManager.createNamedQuery("getUserByEmail");
			query.setParameter("email", user.getEmail());
			foundUser = (User) query.getSingleResult();
		}

		catch(PersistenceException e) {
			e.getMessage();

		}

		finally {
			entityManager.close();
			entityManagerFactory.close();
		}
		return foundUser;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	//returns a list of all users stored in user table
	public List<User> getAllUsers() {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("KreativeVer2");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		List<User> userList = new ArrayList<>();
		try {
			Query query = entityManager.createNamedQuery("getAllUsers");
			userList = query.getResultList();
		}
		catch(PersistenceException e){
			userList = null;
		}
		finally {
			entityManager.close();
			entityManagerFactory.close();
		}
		return userList;
	}
	
	@Override
	//updates field 'phone' of record 'user'
	public boolean updateUserPhone(User user, String phone) {
		
		boolean result = true;
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("KreativeVer2");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		try {
				entityManager.getTransaction().begin();
				User foundUser = entityManager.find(User.class, user.getId());
				foundUser.setPhone(phone);
//				entityManager.persist(foundUser);
				entityManager.getTransaction().commit();
			}
			
		catch(PersistenceException e) {
				e.getMessage();
				result = false;
			}
			
		finally {
				entityManager.close();
				entityManagerFactory.close();
			}
		
		return result;
	}
	
	@Override
	//updates field 'email' of record 'user'
	public boolean updateUserEmail(User user, String email) {
		boolean result = true;
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("KreativeVer2");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		try {
			entityManager.getTransaction().begin();
			User foundUser = entityManager.find(User.class, user.getId());
			foundUser.setEmail(email);
			entityManager.getTransaction().commit();
		}
		catch(PersistenceException e) {
			e.getMessage();
			result = false;
		}
		finally {
			entityManager.close();
			entityManagerFactory.close();
		}
		return result;
	}
	
	@Override
	//updates field 'password' of record 'user'
	// NOT YET IMPLEMENTED
	public boolean updateUserPassword(User user, String password) {
		boolean result = true;
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("KreativeVer2");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		try {
			entityManager.getTransaction().begin();
			User foundUser = entityManager.find(User.class, user.getId());
			foundUser.setPassword(password);
			entityManager.getTransaction().commit();
			}
			
			catch(PersistenceException e) {
				e.getMessage();
				result = false;
			}
			
			finally {
				entityManager.close();
				entityManagerFactory.close();
			}
		
		return result;
	}
	
	@Override
	//creates a folder with set name user.id in local machines file system
	public boolean createUserDirectory(User user) {
		
		boolean result = true;
		File dir = new File("C:\\Users\\Antonio\\eclipse-workspace\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\CaseStudySpring\\resources\\users\\"+user.getId());
		result = dir.mkdir();
		return result;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	//returns list of users where field 'state' matches String parameter
	public List<User> getUsersByState(String state) {
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("KreativeVer2");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		List<User> userList = new ArrayList<>();
		try {
			Query query = entityManager.createNamedQuery("getUsersByState");
			query.setParameter("state", state);
			userList = query.getResultList();
		}
		catch(PersistenceException e){
			userList = null;
		}
		finally {
			entityManager.close();
			entityManagerFactory.close();
		}
		return userList;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	//returns list of users where field 'job' matches String parameter
	public List<User> getUsersByJob(String job) {
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("KreativeVer2");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		List<User> userList = new ArrayList<>();
		
		try {
			Query query = entityManager.createNamedQuery("getUsersByJob");
			query.setParameter("job", job);
			userList = query.getResultList();
		}
		catch(PersistenceException e){
			userList = null;
		}
		finally {
			entityManager.close();
			entityManagerFactory.close();
		}
		return userList;
	}
}
