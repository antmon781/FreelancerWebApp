/*
*
* The following code is a temporary test runner used while writing this web application
* Please disregard.
*
*/
//package com.kreative.runner;
//import java.util.List;
//
//import com.kreative.entities.Photograph;
//import com.kreative.entities.Service;
//import com.kreative.entities.User;
//import com.kreative.services.PhotographServices;
//import com.kreative.services.ServiceServices;
//import com.kreative.services.UserServices;
//
//public class MainRunner {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		UserServices us = new UserServices();
//		User newUser = new User("testuser@test.com", "123123", "Antonio", "Monteiro", "Lynn", "Massachusetts",
//				"617-123-8888", "Photographer");
//		us.createUser(newUser);
////		User foundUser = us.getUserById(1);
////		boolean test = us.updateUserPhone(foundUser, "781-123-9999");
//////		us.updateUserPassword(foundUser, "111");
////		System.out.println(test);
////		System.out.println(us.updateUserEmail(foundUser, "monant95@live.com"));
////		System.out.println(us.updateUserPassword(foundUser, "123123"));
////		System.out.println(foundUser.toString());
////		User newUser = new User();
////		newUser = us.getUserByEmail("monant95@live.com");
////		System.out.println(newUser.toString());
////		UserServices us = new UserServices();
////		User user = new User("monant95@live.com", "123123", "Antonio", "Monteiro",
////				"Lynn", "MA", "6171111111", "Customer");
////		System.out.println("Create User: " + us.createUser(user));
////		
////		User foundUser = us.getUserByEmail("monant95@live.com");
////		System.out.println("Found User by Email: " + foundUser.toString());
////		
////		boolean result = us.validateUser("monant95@live.com", "123123");
////		System.out.println("Validated user: " + result);
////		result = us.validateUser("monants95@live.com", "123123");
////		System.out.println("Validated user: (wrong email): " + result);
////		
////		Photograph photo = new Photograph(foundUser, "1", "/fake/path");
////		PhotographServices ps = new PhotographServices();
////		System.out.println("Added photo: " + ps.addPhoto(photo));
////		Photograph photo3 = new Photograph(foundUser, "3", "/fake/path");
////		System.out.println("Added photo: " + ps.addPhoto(photo3));
//		
////		ServiceServices ss = new ServiceServices();
////		Service service = new Service(foundUser, "Portrait", "5 portrait photos taken by me");
////		System.out.println("Added service: " + ss.addService(service));
////		
////		System.out.println(ps.getPhotographsByUser(foundUser));
////		System.out.println(ss.getServicesByUser(foundUser));
////		
//		ServiceServices ss = new ServiceServices();
//		Service service = new Service(us.getUserById(1), "Portraits", "String goes here");
//		System.out.println(ss.addService(service));
////		PhotographServices ps = new PhotographServices();
////		User user = us.getUserById(2201);
////		Photograph p = new Photograph(user, "5", "/resources/users/1/5.jpg");
////		System.out.println(ps.addPhoto(p));
////		p = new Photograph(user, "6", "/resources/users/1/3.jpg");
////		System.out.println(ps.addPhoto(p));
////		p = new Photograph(user, "7", "/resources/users/1/4.jpg");
////		System.out.println(ps.addPhoto(p));
////		
////		boolean test = us.updateUserPhone(foundUser, "781-123-4567");
////		us.updateUserPassword(foundUser, "111");
////		System.out.println(test + foundUser.toString());
////		List<Photograph> pL = ps.getPhotographsByUser(user);
////		for(Photograph e : pL) {
////			System.out.println(e.getPhotograph());
////		}
//	}
//
//}
