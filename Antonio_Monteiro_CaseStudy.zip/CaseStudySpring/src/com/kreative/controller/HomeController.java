package com.kreative.controller;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.kreative.entities.Photograph;
import com.kreative.entities.Service;
import com.kreative.entities.User;
import com.kreative.services.PhotographServices;
import com.kreative.services.ServiceServices;
import com.kreative.services.UserServices;

@Controller
@SessionAttributes("user")
public class HomeController {
	
	// instantiates Data Access Objects
	PhotographServices ps = new PhotographServices();
	ServiceServices ss = new ServiceServices();
	
	
	//Handles request to visit user edit portfolio page
	@RequestMapping("/editPortfolio")
	public ModelAndView editPortfolioPage(HttpSession session) {
		
		ModelAndView mav = new ModelAndView("editPortfolio");
		User user = (User) session.getAttribute("user"); 		//grabs user object from session 
		List<Photograph> photos = ps.getPhotographsByUser(user);
		mav.addObject("photos", photos);						
		List<Service> serviceList = ss.getServicesByUser(user); 
		mav.addObject("services", serviceList);					
		if(user.getId()<1)										//if user id is default, reroutes to
			mav.setViewName("index");							//home page
		return mav;
	}
	
	//handles request for website landing page
	@RequestMapping(value= {"/", "/home"})
	public ModelAndView landingPage() {
		ModelAndView mav = new ModelAndView("index");
		User user = new User();
		mav.addObject("user", user);
		return mav;
	}
	
	//handles request for search page
	@RequestMapping("/search")
	public ModelAndView searchPage() {
		ModelAndView mav = new ModelAndView();
		UserServices us = new UserServices();
		mav.setViewName("search");
		List<User> userList = us.getAllUsers(); //all available freelancers are shown by default
		mav.addObject("users", userList);
		return mav;
	}
	
	//handles request to filter freelancers by state
	@RequestMapping("/searchByState")
	public ModelAndView searchPageByState(@RequestParam("state") String state) {
		ModelAndView mav = new ModelAndView("search");
		UserServices us = new UserServices();
		List<User> userList = us.getUsersByState(state);
		mav.addObject("users", userList);
		return mav;
	}
	
	//handles request to filer freelancer's by job type
	@RequestMapping("/searchByJob")
	public ModelAndView searchPageByJob(@RequestParam("job") String job) {
		ModelAndView mav = new ModelAndView("search");
		UserServices us = new UserServices();
		List<User> userList = us.getUsersByJob(job);
		mav.addObject("users", userList);
		return mav;
	}
	
	//handles request to view freelancer's portfolio page
	@RequestMapping("/portfolio/{id}")
	public ModelAndView userPortfolio(@PathVariable int id) {
		
		UserServices us = new UserServices();
		ModelAndView mav = new ModelAndView("portfolio");
		mav.addObject("user", us.getUserById(id));
		List<Photograph> photos = ps.getPhotographsByUser(us.getUserById(id));
		mav.addObject("photos", photos);
		List<Service> services = ss.getServicesByUser(us.getUserById(id));
		mav.addObject("services", services);
		return mav;
	}
	
	//handles request to login. Passes email and password from form and validates credentials
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public ModelAndView validateUser(@RequestParam("email") String email,
			@RequestParam("password") String password) {

		ModelAndView mav = new ModelAndView();
		UserServices us = new UserServices();
		
		//if validation passes true, build user profile page using user object data
		if(us.validateUser(email, password)) {
			User user = us.getUserByEmail(email);
			mav.addObject("user", user);
			List<Photograph> photoList = ps.getPhotographsByUser(user);
			mav.addObject("photographs", photoList);
			List<Service> serviceList = ss.getServicesByUser(user);
			mav.addObject("services", serviceList);
			mav.setViewName("editPortfolio");
		} else {
			mav.setViewName("index");
		}
		return mav;
	}
	
	//handles request to signup. Passes form attributes to build user
	@RequestMapping(value="/signup", method=RequestMethod.POST)
	@ModelAttribute("user")
	public ModelAndView registerUser(
			@ModelAttribute("user") @Valid User user,
			BindingResult errors,
			@RequestParam("firstName") String firstName,
			@RequestParam("lastName") String lastName,
			@RequestParam("email") String email,
			@RequestParam("password") String password,
			@RequestParam("city") String city,
			@RequestParam("state") String state,
			@RequestParam("phone") String phone,
			@RequestParam("job") String job) {
		
		//checks if there are errors in form
		if(errors.hasErrors()) {
			ModelAndView mav = new ModelAndView("index");
			return mav;
		}
		
		ModelAndView mav = new ModelAndView();
		UserServices us = new UserServices();
		User foundUser = us.getUserByEmail(email);
		
		//if user is not null, this means user already exists and should not add user
		if(foundUser!=null) {
			mav.setViewName("index");
		}
		else {
			foundUser = new User(email, password, firstName, lastName, city, state, phone, job);
			us.createUser(foundUser);
			User newUser = us.getUserByEmail(email);
			//after user record is created, also
			us.createUserDirectory(newUser);
			mav.addObject("user", newUser);
			mav.setViewName("index");
		}
		return mav;
	}
	
	//handles request to sign user out and redirects to landing page
	@RequestMapping("/signout")
	public String logout(HttpSession session){
		session.invalidate();
		return "redirect:/";
	}
	
	//handles request to change user phone number
	@RequestMapping(value="/editphone", method=RequestMethod.POST)
	public ModelAndView updatePhone(@ModelAttribute("user") User user,
			@RequestParam("newPhone") String phone) {
		
		ModelAndView mav = new ModelAndView();
		System.out.println(phone.toString()+ " " + user.toString());
		UserServices us = new UserServices();
		boolean result = us.updateUserPhone(user, phone);
		
		//keeps list of user photos and services up to date on page refresh
		List<Photograph> photoList = ps.getPhotographsByUser(user);
		mav.addObject("photographs", photoList);
		List<Service> serviceList = ss.getServicesByUser(user);
		mav.addObject("services", serviceList);
		
		//validates phone number change was successful or not and responds accordingly
		if(result) {
			mav.addObject("user", user);
			mav.setViewName("editPortfolio");
			System.out.println("success");
		} else {
			mav.setViewName("/");
			System.out.println("fail");
		}
		return mav;
	}
	
	//handles request to change email address
	@RequestMapping(value="/editEmail", method=RequestMethod.POST)
	public ModelAndView updateEmail(@ModelAttribute("user") User user,
			@RequestParam("newEmail") String email) {
		
		ModelAndView mav = new ModelAndView();
		System.out.println(email.toString()+ " " + user.toString());
		UserServices us = new UserServices();
		boolean result = us.updateUserEmail(user, email);
		
		//keeps user lists up to date on page refresh
		List<Photograph> photoList = ps.getPhotographsByUser(user);
		mav.addObject("photographs", photoList);
		List<Service> serviceList = ss.getServicesByUser(user);
		mav.addObject("services", serviceList);
		
		//validates email change was successful and responds accordingly
		if(result) {
			mav.addObject("user", user);
			mav.setViewName("editPortfolio");
			System.out.println("success");
		} else {
			mav.setViewName("/");
			System.out.println("fail");
		}
		return mav;
	}
	
	//handles request to add a new service
	@RequestMapping(value="/editService", method=RequestMethod.POST)
	public ModelAndView addService(@ModelAttribute("user") User user,
			@RequestParam("serviceName") String serviceName,
			@RequestParam("description") String description) {
		
		ModelAndView mav = new ModelAndView();
		ServiceServices ss = new ServiceServices();
		System.out.println(serviceName);
		System.out.println(description);
		Service service = new Service(user, serviceName, description);
		mav.setViewName("editPortfolio");
		
		//keeps user lists up to date on page refresh
		List<Photograph> photoList = ps.getPhotographsByUser(user);
		mav.addObject("photographs", photoList);
		List<Service> serviceList = ss.getServicesByUser(user);
		mav.addObject("services", serviceList);
		
		//validates if service add is successful or not and responds accordingly
		if(ss.addService(service)) {
			mav.addObject("servicesuccess", "Successful!");
		}
		else {
			mav.addObject("servicesuccess", "failed!");
		}
		
		return mav;
	}
	
	//handles request to upload an image
	@RequestMapping(value="/savefile",method=RequestMethod.POST)  
	public ModelAndView upload(@RequestParam CommonsMultipartFile file, 
			@ModelAttribute("user") User user,
			HttpSession session){  
		
		ModelAndView mav = new ModelAndView();
		//sets the path for directory, creates directory to upload file into, and sets file name
		String uploadDirectory = "/resources/users/" + user.getId() + "/";
		String path=session.getServletContext().getRealPath(uploadDirectory);  
		String filename=file.getOriginalFilename();  

		System.out.println(path+filename);
		
		try {
			//stores image in array of bytes
			byte barr[]=file.getBytes();  
			
			//writes file in user folder
			BufferedOutputStream bout=new BufferedOutputStream(  
					new FileOutputStream(path+"/"+filename));  
			bout.write(barr);  
			bout.flush();
			bout.close();
			
			UserServices us = new UserServices();
			System.out.println(user.getId());
			//adds photograph to database
			Photograph photo = new Photograph(us.getUserById(user.getId()), filename, (uploadDirectory+filename));
			PhotographServices ps = new PhotographServices();
			
			//validates if upload was successful or not and responds accordingly
			if(ps.addPhoto(photo))
				mav.addObject("filesuccess", "Successfully uploaded!");
			else {
				System.out.println("here");
				mav.addObject("filesuccess", "Failed to upload!");
			}
		}
		
		catch(Exception e)
		{
			System.out.println(e);
			mav.addObject("filesuccess", "Failed to upload");
		}
		
		finally {
			mav.setViewName("/editPortfolio");
			//keeps user lists up to date on page refresh
			List<Photograph> photoList = ps.getPhotographsByUser(user);
			mav.addObject("photographs", photoList);
			List<Service> serviceList = ss.getServicesByUser(user);
			mav.addObject("services", serviceList);
		}
		
		return mav;  
	}  
	
	//handles request to delete photograph
	@RequestMapping(value="/deletePhoto",method=RequestMethod.POST)
	public ModelAndView deletePhoto(@RequestParam("selectedPhoto") int photoId,
			@ModelAttribute User user) {
		
		ModelAndView mav = new ModelAndView();
		
		try {
		ps.deletePhotographById(photoId);
		List<Photograph> photoList = ps.getPhotographsByUser(user);
		mav.addObject("photographs", photoList);
		}
		catch(Exception e) {
			System.out.println(e);
		}
		finally {
			mav.setViewName("editPortfolio");
			List<Service> serviceList = ss.getServicesByUser(user);
			mav.addObject("services", serviceList);
		}
		return mav;
	}
	
	//handles request to delete service
	@RequestMapping(value="/deleteService",method=RequestMethod.POST)
	public ModelAndView deleteService(@RequestParam("selectedService") int serviceId,
			@ModelAttribute User user) {
		
		ModelAndView mav = new ModelAndView();
		
		try {
		System.out.println(serviceId);
		ss.deleteServiceById(serviceId);
		List<Service> serviceList = ss.getServicesByUser(user);
		mav.addObject("services", serviceList);
		}
		catch(Exception e) {
			System.out.println(e);
		}
		finally {
			mav.setViewName("editPortfolio");
			List<Photograph> photoList = ps.getPhotographsByUser(user);
			mav.addObject("photographs", photoList);
		}
		return mav;
	}
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
//		binder.setDisallowedFields(new String[] {"email"});
	}
	
	@ExceptionHandler(Exception.class)
	public String handle(Exception e) {
		return "redirect:/";
	}
}
