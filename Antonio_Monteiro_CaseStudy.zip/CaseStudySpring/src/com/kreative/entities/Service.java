package com.kreative.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;

@Entity
@Table
@NamedQuery(query="SELECT e FROM Service e WHERE e.user = :user", name="queryServicesByUser")
public class Service{
	
	@Id
	@GeneratedValue
	private int serviceId;
	
	@Column(nullable=false)
	@Size(min = 1)
	private String serviceName;
	
	@ManyToOne
	@JoinColumn(name="id")
	private User user;
	
	@Column(nullable=false)
	@Size(min = 1)
	private String description;
	
	public Service() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Service(User user, String serviceName, String description) {
		super();
		this.user = user;
		this.serviceName = serviceName;
		this.description = description;
	}
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
}
