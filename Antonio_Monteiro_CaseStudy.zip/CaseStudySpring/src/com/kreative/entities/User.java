package com.kreative.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;



@SuppressWarnings("deprecation")
@Entity
@Table
@NamedQuery(query="SELECT e FROM User e WHERE e.email = :email", name="getUserByEmail")
@NamedQuery(query="SELECT e FROM User e", name="getAllUsers")
@NamedQuery(query="SELECT e FROM User e WHERE e.state = :state", name="getUsersByState")
@NamedQuery(query="SELECT e FROM User e WHERE e.job = :job", name="getUsersByJob")
public class User {
	
	@Id
	@GeneratedValue
	private int id;
	
	@Column(unique=true)
	@Email
	private String email;
	
	@Size(min=6, message = "password must be atleast 6 characters")
	private String password;
	@Size(min=2, message = "name must be atleast 2 characters")
	private String firstName;
	@Size(min=2, message = "name must be atleast 2 characters")
	private String lastName;
	@Size(min=2)
	private String city;
	@Size(min=2)
	private String state;
	
	@Pattern(regexp = "[0-9]{3}-[0-9]{3}-[0-9]{4}")
	private String phone;
	private String job;
	
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public User(String email, String password, String firstName, String lastName, String city, String state,
			String phone, String job) {
		super();
		this.email = email;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.city = city;
		this.state = state;
		this.phone = phone;
		this.job = job;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", email=" + email + ", password=" + password + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", city=" + city + ", state=" + state + ", phone=" + phone + ", job=" + job
				+ "]";
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof User) {
			User other = (User) obj;
			boolean sameEmail = (this.email.equals(other.getEmail()));
			boolean sameFirstName = (this.firstName.equals(other.getFirstName()));
			boolean sameLastName = (this.lastName.equals(other.getLastName()));
			boolean samePass = (this.password.equals(other.getPassword()));
			boolean sameCity = (this.city.equals(other.getCity()));
			boolean sameState = (this.state.equals(other.getState()));
			boolean samePhone = (this.phone.equals(other.getPhone()));
			boolean sameJob = (this.job.equals(other.getJob()));
			if (sameEmail && sameFirstName && sameLastName && samePass && sameCity
					&& sameState && samePhone && sameJob) return true;
			else return false;
		}
		else {
			return false;
		}
	}
}
