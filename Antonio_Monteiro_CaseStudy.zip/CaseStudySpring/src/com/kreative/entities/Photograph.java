package com.kreative.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table
@NamedQuery(query="SELECT e FROM Photograph e WHERE e.user = :user", name="queryPhotographsByUser")
public class Photograph {
	
	@Id
	@GeneratedValue
	private int photoId;
	
	@Column(nullable=false)
	private String photoName;
	
	@ManyToOne
	@JoinColumn(name="id")
	private User user;
	
	private String photograph;
	
	public Photograph() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Photograph(User user, String photoName, String photograph) {
		super();
		this.user = user;
		this.photoName = photoName;
		this.photograph = photograph;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String getPhotograph() {
		return photograph;
	}
	public void setPhotograph(String photograph) {
		this.photograph = photograph;
	}
	public int getPhotoId() {
		return photoId;
	}
	public void setPhotoId(int photoId) {
		this.photoId = photoId;
	}
	public String getPhotoName() {
		return photoName;
	}
	public void setPhotoName(String photoName) {
		this.photoName = photoName;
	}
	
	
}
